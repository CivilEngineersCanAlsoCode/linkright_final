# Module Brief: sync

**Date:** 2026-03-05
**Author:** Bhai
**Module Code:** `sync`
**Module Type:** Standalone
**Status:** Ready for Development

---

## Executive Summary

Sync is a strategic AI-powered career positioning platform that transforms raw professional experience into high-impact "market signals". It is designed to solve the interview conversion problem for Product Managers in India (especially those with title-mismatch issues) by engineering a unified, JD-aligned narrative across all application artifacts.

**Module Category:** Career-Tech / Signal Engineering
**Target Users:** Early-to-mid career PMs (4–8 years) in India
**Complexity Level:** High (Multi-agent, Vector DB integration)

---

## Module Identity

### Module Code & Name

- **Code:** `sync`
- **Name:** `Sync: AI Career Signal Engineering`

### Core Concept

"ChatGPT generates content. Sync engineers signal."
Sync doesn't just write resumes; it models professional memory. It creates a structured, retrievable signal layer that grounds every AI generation in factual, high-impact evidence.

**Task Orchestration Logic**: Sync uses **Beads** (`bd`) as its task management backbone. Every execution stage is a Bead task, and the dependency graph is the source of truth for the entire agentic loop.

### Personality Theme

**Signal Engineering Team**. Sleek, premium, high-performance. The module communicates with a professional but urgent vibe, focusing on outcome over effort. (Communication style: Romanised Hindi/English mix as per user preference).

---

## Module Type

**Type:** Standalone

Sync is an independent domain module. While it follows BMAD Method guidelines and inherits its technical rigor, it operates as a distinct IP-branded system ("Sync") with its own dedicated agents and workflows.

---

## Unique Value Proposition

**What makes this module special:**

- **Signal Over Volume:** Focuses on the quality and alignment of professional signals rather than just mass application.
- **Semantic Grounding:** Uses Chroma Vector DB to semantically retrieve the most relevant "impact blocks" for any given Job Description.
- **Deterministic Validation:** Enforces hard layout constraints (e.g., one-page resume limit) and horizontal/vertical budgets to ensure professional excellence.

**Why users would choose this module:**

Users choose Sync to move from a <1% shortlist rate to ≥5% by bridging the "credibility gap" through structured repositioning and narrative coherence.

---

## User Scenarios

### Target Users

**Persona: Abhishek, the Title-Mismatch PM**

- 4 years of experience performing PM duties at a large MNC but with a "Business Analyst" title.
- Goal: Move to a FAANG-tier PM role with a 40% salary hike.
- Pain: Generic AI tools don't capture the nuance of his product ownership.

### Primary Use Case

Transforming a base resume and raw experience notes into a JD-customized, high-signal ResumeVersion that compiles to exactly one page and scores ≥20% higher on alignment.

### User Journey

1. **Capture**: Abhishek logs daily work reflections. The `refiner` and `parser` agents extract structured signals and store them in the Sync memory layer (Mongo + Chroma).
2. **Optimize**: Abhishek pastes a JD for a "Senior PM" role at Google.
3. **Plan**: The `linker` agent retrieves top-k relevant signals. The `refiner` plans the narrative shift.
4. **Sculpt**: `refiner` rewrites bullets; `sizer` ensures they fit the layout perfectly.
5. **Verify**: `styler` compiles the HTML/CSS; `tracker` logs the version and updates the success ledger.

---

## Agent Architecture

### Agent Count Strategy

A collaborative multi-agent team (8 specialized agents) to ensure separation of concerns between data extraction, narrative sculpting, and technical validation.

### Agent Roster

| Agent          | Name            | Role               | Expertise                                                                    |
| -------------- | --------------- | ------------------ | ---------------------------------------------------------------------------- |
| **Parser**     | Sync-Parser     | Data Architect     | Extracting structured raw data from resumes, Obsidian, and JDs.              |
| **Scout**      | Sync-Scout      | Brand Researcher   | Fetching company branding, colors, and industry-specific context.            |
| **Inquisitor** | Sync-Inquisitor | Signal Interviewer | Conducting "Hidden Experience" interviews to fill JD-specific skill gaps.    |
| **Linker**     | Sync-Linker     | Signal Mapper      | Mapping JD requirements to the most relevant user signals (Retrieval Logic). |
| **Refiner**    | Sync-Refiner    | Narrative Sculptor | Sculpting bullets, summaries, and skills based on Persona and JD intent.     |
| **Sizer**      | Sync-Sizer      | Budget Officer     | Enforcing horizontal/vertical budget and one-page constraints.               |
| **Styler**     | Sync-Styler     | Template Manager   | Managing HTML/CSS templates and company-theming logic.                       |
| **Tracker**    | Sync-Tracker    | Success Officer    | Managing the Success Ledger and application lifecycle.                       |

### Agent Interaction Model

The `Linker` and `Refiner` work in a tight loop. `Refiner` proposes content, `Linker` validates it against retrieved signal, and `Sizer` acts as a hard gatekeeper for layout sanity.

### Agent Communication Style

Premium, technical, and outcome-oriented. Agents provide "Signal Density" reports and "Alignment Uplift" scores.

---

## Workflow Ecosystem

### Core Workflows (Essential)

- **Career Signal Capture + Indexing**: Extract signals from reflections -> Persist to MongoDB -> Embed in Chroma.
- **JD-Based Resume Optimization**: Parse JD -> Semantic Retrieval -> Planning -> Content Sculpting -> Layout Validation -> Storage.

### Feature Workflows (Specialized)

- **LinkedIn Narrative Engine**: Aligning the LinkedIn profile summary and experience sections with the Sync Signal Model.
- **Recruiter Message Generator**: Generating JD-aware, high-conversion outreach messages.

### Utility Workflows (Support)

- **Success Ledger Sync**: Manages and updates the status of applications and calculates the "Interview Conversion Rate".

---

## Tools & Integrations

### MCP Tools

- **MongoDB MCP**: For structured signal storage.
- **Chroma Docker MCP**: For semantic vector search and retrieval.
- **n8n MCP**: For orchestrating complex background workflows and integrations.
- **Obsidian MCP**: For direct ingestion of raw work reflections and notes.
- **Playwright/Puppeteer**: For HTML/CSS rendering and layout validation.
- **Beads CLI (`bd`)**: Mandatory task and dependency management engine. All Sync processes must be initialized as `bd` tasks.

### External Services

- **OpenAI/Claude API**: For reasoning and embedding generation.
- **LinkedIn API (Future)**: For profile synchronization.

### Integrations with Other Modules

- **Core BMAD**: Inherits framework-level agent and workflow mechanics.

---

## Creative Features

### Personality & Theming

**"The Engineering Room"**. Every agent interaction feels like a high-stakes engineering brief. Instead of "I wrote your resume", the agent says "Signal density optimized to 0.85; Alignment uplift confirmed at 22%."

### Easter Eggs & Delighters

- **"The Hidden Signal"**: The Inquisitor agent might find a "hidden" skill from a random reflection and explain how it's the "missing piece" for a JD.
- **"Lore"**: All agents are part of the 'Sync-Force' specialized in signal extraction.

### Module Lore

Sync was born out of the "Signal-Noise Paradox" — where great talent (Sync) is lost in market noise (other tools). The agents are dedicated to bringing order to the professional narrative.

---

## Next Steps

1. **Review this brief** — Ensure the vision and Beads integration are clear.
2. **Setup Beads Schema** — Define the baseline task and dependency graph for Sync's core journeys.
3. **Run create-module workflow** — Build the module structure at `{project-root}/_bmad/sync`.
4. **Create agents** — Use `create-agent` for the 8 Sync agents, ensuring `bd` protocols are in their persona.
5. **Create workflows** — Implement the 3 core Sync workflows with mandatory `bd` status updates.
6. **Test module** — Run a signal capture and optimization loop verified via `bd ready`.

---

_brief created on 2026-03-05 by Bhai using the BMAD Module workflow_
